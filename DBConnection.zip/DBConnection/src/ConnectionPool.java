   import java.sql.*;
   import java.util.*;

    public class ConnectionPool {
      private String jdbcDriver = "com.mysql.jdbc.Driver";
      private String dbUrl = "jdbc:mysql://localhost/484PROJECT?antoReconnect=true&useSSL=false";
      private String dbUsername = "root";
      private String dbPassword = "root";
      private int initialConnections = 10;
      private int incrementalConnections = 5;
      private int maxConnections = 50; 
      private Vector connections = null;
   
       public ConnectionPool() {
      }	 
       public ConnectionPool(String jdbcDriver, String dbUrl, String dbUsername, String dbPassword) {
         this.jdbcDriver = jdbcDriver;
         this.dbUrl = dbUrl;
         this.dbUsername = dbUsername;
         this.dbPassword = dbPassword;
      }
   
       public synchronized void createPool() throws Exception {
         if (connections != null) {
            return;         
         }
         Driver driver = (Driver) (Class.forName(this.jdbcDriver).newInstance());
         DriverManager.registerDriver(driver);
         connections = new Vector();
         createConnections(this.initialConnections);
      }
   
       private void createConnections(int numConnections) throws SQLException {
         for (int x=0; x<numConnections; x++) {
            if (this.maxConnections>0 && this.connections.size() >= this.maxConnections) {
               break;
            }
            try {
               connections.addElement(new PooledConnection(newConnection()));
            } 
                catch (SQLException e) {
                  DLException dle=new DLException(e, "Error in ConnectionPool class");
               }
         }
      }
   
       private Connection newConnection() throws SQLException {
         Connection conn = DriverManager.getConnection(dbUrl, dbUsername,dbPassword);
         if (connections.size() == 0) {
            DatabaseMetaData metaData = conn.getMetaData();
            int driverMaxConnections = metaData.getMaxConnections();
            if (driverMaxConnections > 0
            	&& this.maxConnections > driverMaxConnections) {
               this.maxConnections = driverMaxConnections;
            }
         }
         return conn;
      }
   
       public synchronized Connection getConnection() throws SQLException {
         if (connections == null) {
            return null;
         }
         Connection conn = getFreeConnection();
         while (conn == null) {
            wait(5000);
            conn = getFreeConnection();
         }
         return conn;
      }
   
       private Connection getFreeConnection() throws SQLException {
         Connection conn = findFreeConnection();
         if (conn == null) {
            createConnections(incrementalConnections);
            conn = findFreeConnection();
            if (conn == null) {
               return null;
            }
         }
         return conn;
      }
   
       private Connection findFreeConnection() throws SQLException {
         Connection conn = null;
         PooledConnection pConn = null;
         Enumeration enumerate = connections.elements();
         while (enumerate.hasMoreElements()) {
            pConn = (PooledConnection) enumerate.nextElement();
            if (!pConn.isBusy()) {
               conn = pConn.getConnection();
               pConn.setBusy(true);
               break;
            }
         }
         return conn;
      }
   
       public boolean returnConnection(Connection conn) {
         boolean result = false;
         if (connections == null) {
            return result;
         }
         PooledConnection pConn = null;
         Enumeration enumerate = connections.elements();
         while (enumerate.hasMoreElements()) {
            pConn = (PooledConnection) enumerate.nextElement();
            if (conn == pConn.getConnection()) {
               pConn.setBusy(false);
               result=true;
               break;
            }
         }
         return result;
      }
   
   
       public synchronized void closeConnectionPool() throws SQLException {
         if (connections == null) {
            return;
         }
         PooledConnection pConn = null;
         Enumeration enumerate = connections.elements();
         while (enumerate.hasMoreElements()) {
            pConn = (PooledConnection) enumerate.nextElement();
            if (pConn.isBusy()) {
               wait(5000);
            }
            closeConnection(pConn.getConnection());
            connections.removeElement(pConn);
         }
         connections = null;
      }
   
   
       private void closeConnection(Connection conn) {
         try {
            conn.close();
         } 
             catch (SQLException e) {
               DLException dle=new DLException(e, "Error in ConnectionPool class");
            }
      }
   
   
       private void wait(int mSeconds) {
         try {
            Thread.sleep(mSeconds);
         } 
             catch (InterruptedException e) {
               DLException dle=new DLException(e, "Error in ConnectionPool class");
            }
      }
   
   
       class PooledConnection {
         Connection connection = null;
         boolean busy = false; // Whether this is being used
      // Constructer
          public PooledConnection(Connection connection) {
            this.connection = connection;
         }
      // Accessor
          public Connection getConnection() {
            return connection;
         }
      // Mutator
          public void setConnection(Connection connection) {
            this.connection = connection;
         }
      // Check if this is busy
          public boolean isBusy() {
            return busy;
         }
      // Set this to busy
          public void setBusy(boolean busy) {
            this.busy = busy;
         }
      }
   
   
       PreparedStatement prepare(Connection conn, String query, ArrayList<String> values){
         PreparedStatement sttt=null;
         try{
            sttt=conn.prepareStatement(query);
            for(int i=0;i<values.size();i++){
               sttt.setString(i+1,values.get(i));
            }
         }
             catch(SQLException sqle){
               DLException dle=new DLException(sqle, "SQL qurey: "+query, "Failed to compile statement");
            }
         return sttt;
      }
   
       public ArrayList<ArrayList<String>> getData(Connection conn, String sql){
         ArrayList<ArrayList<String>> results=null;
         PreparedStatement statement;
         ResultSet rs;
         try{
            statement = conn.prepareStatement(sql);
            rs = statement.executeQuery();
            results=ResultSetToArrayList(rs);
         }
             catch(SQLException sqle){
               DLException dle=new DLException(sqle, "SQL qurey: "+sql, "Failed to retrieve data");
            }
         return results;
      }
       public ArrayList<ArrayList<String>> getData(Connection conn, String sql, ArrayList<String> values){
         ArrayList<ArrayList<String>> results=null;
         PreparedStatement statement;
         ResultSet rs;
         try{
            statement = prepare(conn, sql, values);
            rs = statement.executeQuery();
            results=ResultSetToArrayList(rs);
         }
             catch(SQLException sqle){
               DLException dle=new DLException(sqle, "SQL qurey: "+sql, "Failed to retrieve data");
            }
         return results;
      }
      
       public ArrayList<ArrayList<String>> ResultSetToArrayList(ResultSet rs){
         ArrayList<ArrayList<String>> results= new ArrayList<ArrayList<String>>();
         ResultSetMetaData metaData;
         int numberOfColumns; 
         try{
            metaData = rs.getMetaData();
            numberOfColumns = metaData.getColumnCount();
            ArrayList<String> columns= new ArrayList<String>();
            for(int i = 1; i<= numberOfColumns; i++){
               columns.add(metaData.getColumnName(i));
            }
            results.add(columns);
            while (rs.next()){ 
               ArrayList<String> row = new ArrayList<String>();
               for (int i = 1; i <= numberOfColumns; i++){
                  row.add(rs.getString(i));
               }
               results.add(row);
            }
         }
             catch(SQLException sqle){
               DLException dle=new DLException(sqle, "Failed to convert result set to arraylist");
            }
         return results;
      }
   
   
       public static void main(String[] args){
         ConnectionPool pool = new ConnectionPool();
         try{
            pool.createPool();
            pool.createConnections(10);
            Connection conn = pool.getConnection();
            if(conn!=null){
               System.out.println("Get a connection from pool");
            }
            else
               return;
            if(pool.returnConnection(conn)){
               System.out.println("Connection is returned to pool");
            }
            else
               return;				
            pool.closeConnectionPool();
         }
             catch(Exception e){
               DLException dle=new DLException(e, "Error in ConnectionPool class");
            }
      }
   }