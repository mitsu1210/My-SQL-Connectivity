/**
 * Data layer class that mimics the fields of the papers table in the database.
 * Contains methods that allow interaction with the papers table in the database.
 *
 * @authors: rxv4834, mxz5733, mum8177, skj3889
 * @date: 11/07/16
 */

   import java.util.*;
   import java.util.Map.Entry;
   import java.sql.*;
   import java.io.*;
   import java.lang.*;

    public class DLPapers {
    //Fields
      private int paperID;
      private String title;
      private String paper_abstract;
      private String citation;
      MySQLDatabase mysql = new MySQLDatabase();
      private static File stopwordFile = new File("stopwords.txt");
      private ArrayList<String> stopList;
   
    //Constructors
    /**
     * Used when creating a DLPapers object that is accessing an existing entry in the papers table.
     * @param paperID - ID of the paper
     */
       public DLPapers(int paperID){
         this.paperID=paperID;
      }
   
    /**
     * Used when creating a new entry in the papers table.
     * @param paperID
     * @param title
     * @param paper_abstract
     * @param citation
     */
       public DLPapers(int paperID, String title, String paper_abstract, String citation){
         this.paperID=paperID;
         this.title=title;
         this.paper_abstract=paper_abstract;
         this.citation=citation;
      }
    //Methods
       public boolean insert(){
         ArrayList<String> values = new ArrayList<String>();
         String sql = "insert into papers values (?,?,?,?)";
         boolean result = false;
         try{
            if(mysql.conn==null || mysql.conn.getAutoCommit()){
               mysql.connect();
            }
            values.add(String.valueOf(this.paperID));
            values.add(this.title);
            values.add(this.paper_abstract);
            values.add(this.citation);
            result = mysql.setData(sql, values);
            if(mysql.conn!=null && mysql.conn.getAutoCommit()){
               mysql.close();
            }
         }
             catch(SQLException e){
               DLException dle=new DLException(e, "Error in DLPaper insert()");
            }
       
         return result;
      }
   
       public boolean update(){
         ArrayList<String> values = new ArrayList<String>();
         String sql = "update papers set title=?, abstract=?,"
            +"citation=? where id=?";
         boolean result = false;
         try{
            if(mysql.conn==null || mysql.conn.getAutoCommit()){
               mysql.connect();
            }
            values.add(this.title);
            values.add(this.paper_abstract);
            values.add(this.citation);
            values.add(String.valueOf(this.paperID));
            result = mysql.setData(sql, values);
            if(mysql.conn!=null && mysql.conn.getAutoCommit()){
               mysql.close();
            }
         }
             catch(SQLException e){
               DLException dle=new DLException(e, "Error in DLPaper update()");
            }
       
         return result;
      }
   
       public boolean delete(){
         ArrayList<String> values = new ArrayList<String>();
         String sql = "delete from papers where id=?";
         boolean result = false;
         try{
            if(mysql.conn==null || mysql.conn.getAutoCommit()){
               mysql.connect();
            }
            values.add(String.valueOf(this.paperID));
            result = mysql.setData(sql, values);
            if(mysql.conn!=null && mysql.conn.getAutoCommit()){
               mysql.close();
            }
         }
             catch(SQLException e){
               DLException dle=new DLException(e, "Error in DLPaper delete()");
            }
       
         return result;
      }
   
       public boolean populate(){
         String sql = "select * from papers where id=?";
         boolean result=false;
         ArrayList<String> values = new ArrayList<String>();
         ArrayList<ArrayList<String>> ans = new ArrayList<ArrayList<String>>();
         try{
            if(mysql.conn==null || mysql.conn.getAutoCommit()){
               mysql.connect();
            }
            values.add(String.valueOf(this.paperID));
            ans = mysql.getData(sql, values);
            if(ans.size()<=1){
               this.title=null;
               this.paper_abstract=null;
               this.citation=null;
            }
            else{
               this.title=ans.get(1).get(1);
               this.paper_abstract=ans.get(1).get(2);
               this.citation=ans.get(1).get(3);
               result=true;
            }
            if(mysql.conn!=null && mysql.conn.getAutoCommit()){
               mysql.close();
            }
         }
             catch(SQLException e){
               DLException dle=new DLException(e, "Error in DLPaper populate()");
            }
         return result;
      }
   
    /**
     * Searches for papers whose titles contain/match the given query.
     * @return - An ArrayList of paperIDs
     */
       public ArrayList<Integer> search(){
         String sql = "select id from papers where ";
         ArrayList<String> values = new ArrayList<String>();
         String[] strs=new String[]{"","% ","%'","%"+'"'};
         for(String str:strs){
            sql += "title like ? or ";
            values.add(str+this.title+"%");
         }
         sql = sql.substring(0,sql.length()-4);	
         ArrayList<Integer> result = new ArrayList<Integer>();
         try{
            if(mysql.conn==null || mysql.conn.getAutoCommit()){
               mysql.connect();
            }
            ArrayList<ArrayList<String>> ans = mysql.getData(sql, values);
            for(int i=1;i<ans.size();i++){
               result.add(Integer.valueOf(ans.get(i).get(0)));
            }
            if(mysql.conn!=null && mysql.conn.getAutoCommit()){
               mysql.close();
            }
         }
             catch(SQLException e){
               DLException dle=new DLException(e, "Error in DLPaper search()");
            }
         return result;
      }
   
       public ArrayList<Integer> search5(ConnectionPool pool){
         String sql = "select id from papers where ";
         ArrayList<String> values = new ArrayList<String>();
         String[] strs=new String[]{"","% ","%'","%"+'"'};
         for(String str:strs){
            sql += "title like ? or ";
            values.add(str+this.title+"%");
         }
         sql = sql.substring(0,sql.length()-4);	
         ArrayList<Integer> result = new ArrayList<Integer>();
         
         try{
         // get a connection from pool
            Connection conn = pool.getConnection();
            if(conn==null){
               return result;
            }
            ArrayList<ArrayList<String>> ans = pool.getData(conn, sql, values);
            for(int i=1;i<ans.size();i++){
               result.add(Integer.valueOf(ans.get(i).get(0)));
            }
         // return a connection to pool
            pool.returnConnection(conn);
         }
             catch(SQLException e){
               DLException dle=new DLException(e, "Error in DLPaper search5()");
            }
         return result;
      }
   
    /**
     * Searches for papers whose titles contain any word in the given query.
     * @return - An ArrayList of paperIDs
     */
       public ArrayList<Integer> search2(){
         String[] tokens = this.title.split("[ ',.?:;$%+()\\-\\*]+");
         ArrayList<String> tokens2 = new ArrayList<String>();
         this.createStopList();
         for(String token:tokens){
            if (this.searchStopWord(token) != -1) {
               continue;
            }
            if(!token.equals(""))
               tokens2.add(token);
         }
         String sql = "select id from papers where ";
         ArrayList<String> values = new ArrayList<String>();
         String[] strs=new String[]{"","% ","%'","%"+'"'};
         for(int i=0;i<tokens2.size();i++){
            for(String str:strs){
               sql += "title like ? or ";
               values.add(str+tokens2.get(i)+"%");
            }
         }
         sql = sql.substring(0,sql.length()-3);	
         ArrayList<Integer> result = new ArrayList<Integer>();
         try{
            if(mysql.conn==null || mysql.conn.getAutoCommit()){
               mysql.connect();
            }
            ArrayList<ArrayList<String>> ans = mysql.getData(sql, values);
            for(int i=1;i<ans.size();i++){
               result.add(Integer.valueOf(ans.get(i).get(0)));
            }
            if(mysql.conn!=null && mysql.conn.getAutoCommit()){
               mysql.close();
            }
         }
             catch(SQLException e){
               DLException dle=new DLException(e, "Error in DLPaper search2()");
            }
         return result;
      }
   
       protected void createStopList(){
         stopList = new ArrayList<String>();
           
         try {
            Scanner scan = new Scanner(stopwordFile);
            while(scan.hasNextLine()) {
               stopList.add(scan.nextLine());
            }
         }
             catch(Exception e) {
               DLException dle=new DLException(e, "Error in DLPaper createStopList()");
            }
      }
   
    /**
     * Searches for papers whose titles contain any word in the given query.
     * @param - the word being searched
     * @return - position in the list of stop words, or -1 if not found
     */
       protected int searchStopWord(String key) {
         int lo = 0;
         int hi = stopList.size() -1;
         while(lo <= hi) {
            int mid = lo + (hi-lo)/2;
            int result = key.compareTo(stopList.get(mid));
            if(result < 0) hi = mid - 1;
            else if(result > 0) lo = mid + 1;
            else 
               return mid;
         }
         return -1;
      }
   
    /**
     * Searches for papers whose titles contain stem of any word in the given query.
     * @return - An ArrayList of paperIDs
     */
       public ArrayList<Integer> search3(){
         String[] tokens = this.title.split("[ ',.?:;$%+()\\-\\*]+");
         ArrayList<String> tokens2 = new ArrayList<String>();
         this.createStopList();
         for(String token:tokens){
            if (this.searchStopWord(token) != -1) {
               continue;
            }
            if(token.equals(""))
               continue;
            Stemmer stemmer = new Stemmer();
            stemmer.add(token.toCharArray(), token.length());
            stemmer.stem();
            String stemmedToken = stemmer.toString();
            tokens2.add(stemmedToken);
         }
         String sql = "select id from papers where ";
         ArrayList<String> values = new ArrayList<String>();
         String[] strs=new String[]{"","% ","%'","%"+'"'};
         for(int i=0;i<tokens2.size();i++){
            for(String str:strs){
               sql += "title like ? or ";
               values.add(str+tokens2.get(i)+"%");
            }	
         }
         sql = sql.substring(0,sql.length()-4);
      
         ArrayList<Integer> result = new ArrayList<Integer>();
         try{
            if(mysql.conn==null || mysql.conn.getAutoCommit()){
               mysql.connect();
            }
            ArrayList<ArrayList<String>> ans = mysql.getData(sql, values);
            for(int i=1;i<ans.size();i++){
               result.add(Integer.valueOf(ans.get(i).get(0)));
            }
            if(mysql.conn!=null && mysql.conn.getAutoCommit()){
               mysql.close();
            }
         }
             catch(SQLException e){
               DLException dle=new DLException(e, "Error in DLPaper search3()");
            }
         return result;
      }
   
    /**
     * Calculate the difference of 2 arrays.
     * @return - A ArrayList of paperIDs that is in list2 but not in list1
     */
       public ArrayList<Integer> differenceSet(ArrayList<Integer> list1, ArrayList<Integer> list2){			   
         ArrayList<Integer> result = new ArrayList<Integer>();
         HashSet<Integer> set = new HashSet<Integer>();
         for(int i : list1){
            if(!set.contains(i))
               set.add(i);
         }
         for(int i : list2){
            if(!set.contains(i))
               result.add(i);
         }
         return result;
      }
   
    /**
     * Searches for papers whose titles contain stem of any word in the given query and sort result by relevancy.
     * @return - An ArrayList of paperIDs sorted by relevancy
     */
       public ArrayList<Integer> search4(){
         String[] tokens = this.title.split("[ ',.?:;$%+()\\-\\*]+");
         ArrayList<String> tokens2 = new ArrayList<String>();
         this.createStopList();
         for(String token:tokens){
            if (this.searchStopWord(token) != -1) {
               continue;
            }
            if(token.equals(""))
               continue;
            Stemmer stemmer = new Stemmer();
            stemmer.add(token.toCharArray(), token.length());
            stemmer.stem();
            String stemmedToken = stemmer.toString();
            tokens2.add(stemmedToken);
         }
         String sql = "select id from papers where ";
         String[] strs=new String[]{"","% ","%'","%"+'"'};
         for(String str:strs){
            sql += "title like ? or ";
         }
         sql = sql.substring(0,sql.length()-4);
      
         ArrayList<Integer> result = new ArrayList<Integer>();
         HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
         try{
            if(mysql.conn==null || mysql.conn.getAutoCommit()){
               mysql.connect();
            }
            for(String token:tokens2){
               ArrayList<String> values = new ArrayList<String>();
               for(String str:strs){
                  values.add(str+token+"%");
               }	
               ArrayList<ArrayList<String>> ans = mysql.getData(sql, values);
               for(int i=1;i<ans.size();i++){
                  int index=Integer.valueOf(ans.get(i).get(0));
                  if(map.containsKey(index))
                     map.put(index, map.get(index)+1);
                  else
                     map.put(index,1);
               }
            }
         
            ArrayList<Pair> pairs = new ArrayList<Pair>();
            Set<Entry<Integer, Integer>> set = map.entrySet();
            for(Entry<Integer, Integer> entry : set) { 
               Pair pair = new Pair();
               pair.index = entry.getKey();
               pair.count = entry.getValue();
               pairs.add(pair);
            }
            Collections.sort(pairs, new Compare());
         
            for(int i=0;i<pairs.size();i++){
               result.add(pairs.get(i).index);
            }
            if(mysql.conn!=null && mysql.conn.getAutoCommit()){
               mysql.close();
            }
         }
             catch(SQLException e){
               DLException dle=new DLException(e, "Error in DLPaper search4()");
            }
         return result;
      }
   
       class Pair{
         int index;
         int count;
      }
       class Compare implements Comparator<Pair>{
         int index;
         int count;
      //@Override
          public int compare(Pair pair1, Pair pair2){
            return pair2.count-pair1.count;
         }
      }
   
      //Accessors
       public int getID() {
         return this.paperID;
      }
       public String getTitle() {
         return this.title;
      }
       public String getAbstract() {
         return this.paper_abstract;
      }
       public String getCitation() {
         return this.citation;
      }
      //Mutators
       public void setID(int paperID) {
         this.paperID=paperID;
      }
       public void setTitle(String title) {
         this.title=title;
      }
       public void setAbstract(String paper_abstract) {
         this.paper_abstract=paper_abstract;
      }
       public void setCitation(String citation) {
         this.citation=citation;
      }
     
       public static void main(String[] args){
         DLPapers test = new DLPapers(0);
         test.setTitle("ted the boxes optimize");
         
         System.out.println("\n Testing search() method: expected result empty ArrayList");
         ArrayList<Integer> ans1 = test.search();
         for(int i=0;i<ans1.size();i++){
            System.out.print(ans1.get(i));  
         }
         System.out.println("\n Output in UI: something like 'Sorry, no result exactly match your criteria'");
      	
         System.out.println("\n Testing search2() method: expected result 1");  
         ArrayList<Integer> ans2 = test.search2();
         for(int i=0;i<ans2.size();i++){
            System.out.print(ans2.get(i));  
         }
         System.out.println("\n Testing search3() method: expected result 12");
         ArrayList<Integer> ans3 = test.search3();
         for(int i=0;i<ans3.size();i++){
            System.out.print(ans3.get(i));  
         }
         
         System.out.println("\n Testing search4() method: expected result 21");
         ArrayList<Integer> ans4 = test.search4();
         for(int i=0;i<ans4.size();i++){
            System.out.print(ans4.get(i));  
         }
         System.out.println("\n Output in UI: something like 'You may also be interested in:'");	
         ArrayList<Integer> ans4difference = test.differenceSet(ans1,ans4);
         for(int i=0;i<ans4difference.size();i++){
            System.out.print(ans4difference.get(i));  
         }
         
         test = new DLPapers(0,"test","test","test");
         test.insert();
         test = new DLPapers(0);
         test.populate();
         System.out.println("\n Testing insert() method:\n"+test.getTitle()+test.getAbstract()+test.getCitation());
      	
         test.setTitle("newTitle");
         test.setAbstract("newAbstract");
         test.setCitation("newCitation");
         test.update();
         test.populate();
         System.out.println("\n Testing update() method:\n"+test.getTitle()+test.getAbstract()+test.getCitation());
      	
         test.delete();
         test.populate();
         System.out.println("\n Testing delete() method:\n"+test.getTitle()+test.getAbstract()+test.getCitation());
         
         ConnectionPool pool = new ConnectionPool();
         try{
         	// create a pool and crate connections
            pool.createPool();
            test = new DLPapers(0,"TED","0","0");
            // search via connection pool
            ArrayList<Integer> ans5 = test.search5(pool);
            System.out.println("\n Testing search5() method: expected result 1");
            for(int i:ans5)
               System.out.print(i);
            // close a pool
            pool.closeConnectionPool();
         }
             catch(Exception e){
               DLException dle=new DLException(e, "Error in DLPaper main()");
            }
      	
      }
   }